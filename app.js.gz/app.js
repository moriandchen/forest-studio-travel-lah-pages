const seed = {
  version: 4,
  mode: 'Before Trip',
  lastBackup: '',
  trip: { city:'Bangkok', country:'Thailand', start:'2026-12-12', end:'2026-12-16' },
  stay: { name:'Grande Centre Point', address:'Bangkok, Thailand', checkin:'15:00', checkout:'12:00', booking:'GCP-2719' },
  budget: 3000,
  packing:[
    {id:'p1',name:'Passport',done:true},{id:'p2',name:'Wallet',done:true},{id:'p3',name:'Phone',done:true},{id:'p4',name:'Power bank',done:true},
    {id:'p5',name:'Charging cable',done:true},{id:'p6',name:'Travel adapter',done:true},{id:'p7',name:'Concert ticket',done:true},{id:'p8',name:'Hotel booking',done:true},
    {id:'p9',name:'Travel insurance',done:true},{id:'p10',name:'Medicine',done:true},{id:'p11',name:'Clothes',done:true},{id:'p12',name:'Toiletries',done:true},
    {id:'p13',name:'Umbrella',done:false},{id:'p14',name:'Extra tote bag',done:false},{id:'p15',name:'Snacks',done:false},{id:'p16',name:'Sunglasses',done:false}
  ],
  expenses:[
    {id:'e1',name:'Airport train',amount:45},{id:'e2',name:'Lunch',amount:62},{id:'e3',name:'Coffee',amount:18},{id:'e4',name:'Shopping',amount:717}
  ],
  places:[
    {id:'l1',icon:'🌸',name:'Impact Arena',category:'Must go',note:'Event'},
    {id:'l2',icon:'🛍️',name:'Siam Paragon',category:'Shopping',note:''},
    {id:'l3',icon:'☕',name:'Coffee stop',category:'Food',note:'Saved nearby'},
    {id:'l4',icon:'🍜',name:'Dinner place',category:'Food',note:''},
    {id:'l5',icon:'🛍️',name:'CentralWorld',category:'Shopping',note:''},
    {id:'l6',icon:'📷',name:'Photo spot',category:'All',note:'Saved'},
    {id:'l7',icon:'🌿',name:'Park walk',category:'All',note:'Maybe'},
    {id:'l8',icon:'🎁',name:'Souvenir shop',category:'Shopping',note:''}
  ],
  plans:[
    {id:'d1',date:'2026-12-12',time:'09:30',title:'✈ Flight to Bangkok',meta:'KUL → BKK'},
    {id:'d2',date:'2026-12-12',time:'14:00',title:'🏨 Check-in',meta:'Drop luggage first'},
    {id:'d3',date:'2026-12-12',time:'17:30',title:'📍 Siam',meta:'Dinner + quick walk'},
    {id:'d4',date:'2026-12-12',time:'20:00',title:'🌸 PP KRIT CONCERT',meta:'Ticket ready ✓'},
    {id:'d5',date:'2026-12-13',time:'10:30',title:'☕ Slow morning',meta:'Coffee nearby'},
    {id:'d6',date:'2026-12-13',time:'14:00',title:'🛍️ CentralWorld',meta:'Shopping'}
  ],
  tickets:[
    {id:'t1',type:'FLIGHT',title:'KUL → BKK',date:'2026-12-12',time:'09:30',place:'KLIA',seat:'14A',code:'FLIGHT-QL7A9',qr:''},
    {id:'t2',type:'EVENT',title:'PP KRIT CONCERT 🌸',date:'2026-12-12',time:'20:00',place:'Impact Arena',seat:'A12',code:'PPKRIT-A12-2719',qr:''},
    {id:'t3',type:'RETURN',title:'BKK → KUL',date:'2026-12-16',time:'18:45',place:'Bangkok',seat:'18F',code:'RETURN-N5K2P',qr:''}
  ],
  gohome:[
    {id:'g1',name:'Passport',done:false},{id:'g2',name:'Wallet',done:false},{id:'g3',name:'Phone',done:false},{id:'g4',name:'Charger',done:false},
    {id:'g5',name:'Power bank',done:false},{id:'g6',name:'All luggage',done:false},{id:'g7',name:'Purchases',done:false},{id:'g8',name:'Hotel room checked',done:false},{id:'g9',name:'Bathroom / wardrobe checked',done:false},{id:'g10',name:'Hotel safe checked',done:false},{id:'g11',name:'Keys / room cards returned',done:false},{id:'g12',name:'Airport transport',done:false}
  ]
};

const LS='travelLahV1';
const OLD_KEYS=['travelLahV03','travelLahV02'];
const RECOVERY_LS='travelLahV1Recovery';
let data = load();
let activePlaceFilter='All';
let selectedTodayDate='';
let pendingTicketQr='';

function clone(x){ return JSON.parse(JSON.stringify(x)); }
function uid(prefix){ return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`; }
function normalizeData(saved){
  const base=clone(seed);
  if(!saved || ![2,3,4].includes(Number(saved.version))) return base;
  const merged={...base,...saved,version:4};
  merged.trip={...base.trip,...(saved.trip||{})};
  merged.stay={...base.stay,...(saved.stay||{})};
  for(const key of ['packing','expenses','places','plans','tickets','gohome']) if(!Array.isArray(merged[key])) merged[key]=clone(base[key]);
  if(!('lastBackup' in merged)) merged.lastBackup='';
  return merged;
}
function load(){
  try{
    const current=JSON.parse(localStorage.getItem(LS));
    if(current) return normalizeData(current);
    for(const key of OLD_KEYS){
      const old=JSON.parse(localStorage.getItem(key));
      if(old){const migrated=normalizeData(old); localStorage.setItem(LS,JSON.stringify(migrated)); return migrated;}
    }
    return clone(seed);
  }catch{return clone(seed)}
}
function save(){ data.version=4; localStorage.setItem(LS,JSON.stringify(data)); render(); }
function qs(s){return document.querySelector(s)}
function qsa(s){return [...document.querySelectorAll(s)]}
function esc(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function toast(msg){const t=qs('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove('show'),1500)}
function localISO(d=new Date()){const z=new Date(d.getTime()-d.getTimezoneOffset()*60000);return z.toISOString().slice(0,10)}
function parseDate(s){return new Date(`${s}T00:00:00`)}
function fmtDate(s,opt={day:'numeric',month:'short',year:'numeric'}){if(!s)return '—';return parseDate(s).toLocaleDateString('en-GB',opt)}
function fmtRange(start,end){
  if(!start||!end)return 'Dates not set';
  const a=parseDate(start),b=parseDate(end),sameMonth=a.getMonth()===b.getMonth()&&a.getFullYear()===b.getFullYear();
  if(sameMonth)return `${a.getDate()}–${b.getDate()} ${a.toLocaleDateString('en-GB',{month:'short'})} ${a.getFullYear()}`;
  return `${fmtDate(start,{day:'numeric',month:'short'})} – ${fmtDate(end,{day:'numeric',month:'short',year:'numeric'})}`;
}
function daysBetween(a,b){return Math.ceil((parseDate(b)-parseDate(a))/86400000)}
function greeting(){const h=new Date().getHours();return h<12?'Good morning, CEO.':h<18?'Good afternoon, CEO.':'Good evening, CEO.'}
function tripPhase(){
  const now=localISO();
  if(now<data.trip.start)return 'before';
  if(now>data.trip.end)return 'after';
  if(now===data.trip.end)return 'lastday';
  return 'travel';
}
function addDays(iso,delta){const d=parseDate(iso);d.setDate(d.getDate()+delta);return localISO(d)}
function nextTicket(){
  const now=localISO(), nowTime=new Date().toTimeString().slice(0,5);
  return data.tickets.slice().sort((a,b)=>(a.date+(a.time||'99:99')).localeCompare(b.date+(b.time||'99:99'))).find(t=>t.date>now || (t.date===now && (t.time||'23:59')>=nowTime)) || null;
}

function showView(id){
  qsa('.view').forEach(v=>v.classList.toggle('active',v.id===id));
  qsa('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.open===id));
  window.scrollTo({top:0,behavior:'smooth'});
}
qsa('[data-open]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.open)));
qsa('.back').forEach(b=>b.addEventListener('click',()=>showView('home')));
qsa('.dialogClose').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));

function tripDayFor(date){
  if(!data.trip.start||!data.trip.end||date<data.trip.start||date>data.trip.end)return null;
  return daysBetween(data.trip.start,date)+1;
}
function effectiveTodayDate(){
  const now=localISO();
  if(selectedTodayDate && selectedTodayDate>=data.trip.start && selectedTodayDate<=data.trip.end)return selectedTodayDate;
  if(now>=data.trip.start && now<=data.trip.end)return now;
  const dates=[...new Set(data.plans.map(p=>p.date))].filter(d=>d>=data.trip.start&&d<=data.trip.end).sort();
  if(now<data.trip.start)return dates[0]||data.trip.start;
  return data.trip.end;
}
function shiftSelectedDay(delta){
  const current=effectiveTodayDate();
  const candidate=addDays(current,delta);
  if(candidate<data.trip.start||candidate>data.trip.end)return;
  selectedTodayDate=candidate;renderToday();
}
function plansFor(date){return data.plans.filter(p=>p.date===date).sort((a,b)=>(a.time||'99:99').localeCompare(b.time||'99:99'))}
function nextPlan(){
  const now=localISO();
  const nowTime=new Date().toTimeString().slice(0,5);
  return data.plans.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).find(p=>p.date>now || (p.date===now && (p.time||'23:59')>=nowTime)) || null;
}
function renderTimeline(target, items){
  const now=localISO(), nowTime=new Date().toTimeString().slice(0,5), next=nextPlan();
  qs(target).innerHTML=items.map(p=>{
    const isPast=p.date<now || (p.date===now && p.time && p.time<nowTime);
    const isNext=next && p.id===next.id;
    return `<div class="timeline-item ${isPast?'is-past':''} ${isNext?'is-next':''}"><span class="time">${esc(p.time||'—')}</span><span class="dot"></span><div><b>${esc(p.title)}${isNext?'<em class="next-tag">NEXT</em>':''}</b><small>${esc(p.meta||'')}</small></div><button class="row-delete" data-plan-delete="${p.id}" aria-label="Delete">×</button></div>`;
  }).join('');
  qsa(`${target} [data-plan-delete]`).forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();data.plans=data.plans.filter(p=>p.id!==b.dataset.planDelete);save();toast('Plan removed')}));
}
function renderPhaseAction(){
  const phase=tripPhase(), box=qs('#phaseAction');
  let open='packing',label='BEFORE TRIP',title='Finish packing',meta='';
  const packed=data.packing.filter(x=>x.done).length, packLeft=Math.max(0,data.packing.length-packed);
  if(phase==='before'){
    if(packLeft){open='packing';title='Finish packing';meta=`${packLeft} item${packLeft===1?'':'s'} left`;}
    else {open='tickets';title='Travel wallet ready';meta=`${data.tickets.length} ticket${data.tickets.length===1?'':'s'} saved`;}
  }else if(phase==='travel'){
    label='ON TRIP';open='tickets';const t=nextTicket();title=t?'Open next ticket':'Open travel wallet';meta=t?`${fmtDate(t.date,{day:'numeric',month:'short'})}${t.time?' · '+t.time:''}`:`${data.tickets.length} tickets ready`;
  }else if(phase==='lastday'){
    label='GO HOME';open='gohome';const left=data.gohome.filter(x=>!x.done).length;title='Final room check';meta=left?`${left} checks left`:'All checks complete ✓';
  }else{
    label='TRIP COMPLETE';open='more';title='Save your trip backup';meta=data.lastBackup?'Backup ready':'Keep a copy before clearing browser data';
  }
  box.dataset.open=open;qs('#phaseActionLabel').textContent=label;qs('#phaseActionTitle').textContent=title;qs('#phaseActionMeta').textContent=meta;
}
function renderTrip(){
  qs('#greeting').textContent=greeting();
  qs('#tripCity').textContent=data.trip.city||'My Trip';
  qs('#tripDates').textContent=fmtRange(data.trip.start,data.trip.end);
  qs('#goHomeTitle').textContent=`Before leaving ${data.trip.city||'your trip'}`;
  const now=localISO(),count=daysBetween(now,data.trip.start),day=tripDayFor(now),phase=tripPhase();
  qs('#phaseStatus').textContent={before:'● PREP',travel:'● ON TRIP',lastday:'● GO HOME',after:'● COMPLETE'}[phase];
  const countdown=qs('#countdown');
  if(data.mode==='Travel Mode'){
    countdown.innerHTML=`<span>${day?`DAY ${day}`:'TRIP'}</span><small>${esc(data.trip.city)}</small>`;
  }else if(count>0){countdown.innerHTML=`<span>${count}</span><small>days to go</small>`}
  else if(now<=data.trip.end){countdown.innerHTML=`<span>${day?`DAY ${day}`:'TODAY'}</span><small>${esc(data.trip.city)}</small>`}
  else{countdown.innerHTML=`<span>✓</span><small>trip complete</small>`}

  const next=nextPlan();
  if(next){qs('#nextTitle').textContent=next.title;qs('#nextMeta').textContent=`${fmtDate(next.date,{day:'numeric',month:'short'})}${next.time?' · '+next.time:''}${next.meta?' · '+next.meta:''}`}
  else{qs('#nextTitle').textContent='No upcoming plans';qs('#nextMeta').textContent='Add your next stop when ready.'}
  renderPhaseAction();
}
function renderToday(){
  selectedTodayDate=effectiveTodayDate();
  const items=plansFor(selectedTodayDate), now=localISO(), nowTime=new Date().toTimeString().slice(0,5);
  let previewItems=items;
  if(selectedTodayDate===now){const upcoming=items.filter(p=>!p.time||p.time>=nowTime);previewItems=upcoming.length?upcoming:items.slice(-1);}
  renderTimeline('#todayPreview',previewItems);
  renderTimeline('#todayFull',items);
  qs('#todayEmpty').classList.toggle('hidden',items.length>0);
  const day=tripDayFor(selectedTodayDate);
  qs('#todayCityDay').textContent=`${data.trip.city||'Trip'} · ${day?`Day ${day}`:'Preview'}`;
  qs('#todayDateText').textContent=parseDate(selectedTodayDate).toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'short'});
  qs('#todayBadge').textContent=selectedTodayDate===now?'TODAY':selectedTodayDate>now?'UPCOMING':'PAST';
  qs('#todayHomeTitle').textContent=selectedTodayDate===now?'Today':now<data.trip.start?'First travel day':'Travel day';
  qs('#prevDayBtn').disabled=selectedTodayDate<=data.trip.start;
  qs('#nextDayBtn').disabled=selectedTodayDate>=data.trip.end;
}
function renderPacking(){
  const done=data.packing.filter(x=>x.done).length,total=data.packing.length;
  qs('#packDone').textContent=done;qs('#packLeft').textContent=total-done;qs('#packingSmall').textContent=`${done} / ${total}`;
  qs('#packingList').innerHTML=data.packing.map(x=>`<div class="check-item ${x.done?'checked':''}"><input type="checkbox" data-pack="${x.id}" ${x.done?'checked':''}><label>${esc(x.name)}</label><button class="row-delete" data-pack-delete="${x.id}" aria-label="Delete">×</button></div>`).join('');
  qsa('[data-pack]').forEach(c=>c.addEventListener('change',()=>{const item=data.packing.find(x=>x.id===c.dataset.pack);if(item)item.done=c.checked;save()}));
  qsa('[data-pack-delete]').forEach(b=>b.addEventListener('click',()=>{data.packing=data.packing.filter(x=>x.id!==b.dataset.packDelete);save();toast('Packing item removed')}));
  const pct=total?Math.round(done/total*100):0;qs('#prepProgressText').textContent=pct+'%';qs('#prepProgressBar').style.width=pct+'%';
}
function renderMoney(){
  const spent=data.expenses.reduce((a,x)=>a+Number(x.amount||0),0),remaining=Number(data.budget||0)-spent;
  qs('#moneyBudget').textContent=`Budget RM ${Number(data.budget||0).toFixed(0)}`;qs('#moneySpent').textContent=`Spent RM ${spent.toFixed(0)}`;qs('#moneyRemaining').textContent=`RM ${remaining.toFixed(0)}`;qs('#moneySmall').textContent=`RM ${remaining.toFixed(0)} left`;
  qs('#expenseList').innerHTML=data.expenses.slice().reverse().map(x=>`<div class="expense-item"><span>${esc(x.name)}</span><div><b>RM ${Number(x.amount).toFixed(2).replace('.00','')}</b><button class="row-delete" data-expense-delete="${x.id}">×</button></div></div>`).join('');
  qsa('[data-expense-delete]').forEach(b=>b.addEventListener('click',()=>{data.expenses=data.expenses.filter(x=>x.id!==b.dataset.expenseDelete);save();toast('Expense removed')}));
}
function renderPlaces(){
  const list=activePlaceFilter==='All'?data.places:data.places.filter(x=>x.category===activePlaceFilter);
  qs('#placesSmall').textContent=`${data.places.length} saved`;
  qs('#placesList').innerHTML=list.map(x=>`<div class="place-item"><div class="place-icon">${esc(x.icon||'📍')}</div><div><b>${esc(x.name)}</b><small>${esc([x.category,x.note].filter(Boolean).join(' · '))}</small></div><div class="row-actions"><button data-place-map="${x.id}" title="Open maps">↗</button><button class="row-delete" data-place-delete="${x.id}" title="Delete">×</button></div></div>`).join('');
  qsa('[data-place-map]').forEach(b=>b.addEventListener('click',()=>{const p=data.places.find(x=>x.id===b.dataset.placeMap);if(p)openMaps(p.name)}));
  qsa('[data-place-delete]').forEach(b=>b.addEventListener('click',()=>{data.places=data.places.filter(x=>x.id!==b.dataset.placeDelete);save();toast('Place removed')}));
}
function renderStay(){
  const s=data.stay;qs('#hotelName').textContent=s.name||'No hotel yet';qs('#hotelAddress').textContent=s.address||'Address not set';qs('#hotelBooking').textContent=s.booking||'—';
  qs('#hotelTimes').textContent=`Check-in ${s.checkin||'—'} · Check-out ${s.checkout||'—'}`;
  qs('#hotelDateRange').textContent=`${fmtDate(data.trip.start,{day:'numeric',month:'short'}).toUpperCase()} – ${fmtDate(data.trip.end,{day:'numeric',month:'short'}).toUpperCase()}`;
  qs('#hotelVisual').textContent=(data.trip.city||'TRIP').slice(0,3).toUpperCase();qs('#staySmall').textContent=s.name?'1 booking':'No booking';
}
function renderTickets(){
  qs('#ticketsSmall').textContent=`${data.tickets.length} ready`;
  qs('#ticketsList').innerHTML=data.tickets.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map(t=>`<article class="ticket-card ${t.type==='EVENT'?'featured':''}" data-ticket-card="${t.id}"><span class="ticket-type">${esc(t.type)}</span><h3>${esc(t.title)}</h3><p>${esc(fmtDate(t.date,{day:'numeric',month:'short'}))}${t.time?' · '+esc(t.time):''}${t.place?' · '+esc(t.place):''}</p><div class="ticket-bottom"><span>${t.seat?'Seat '+esc(t.seat):esc(t.code||'No reference')}</span><div class="ticket-actions"><button class="soft-btn" data-ticket-qr="${t.id}">View</button><button class="icon-btn" data-ticket-edit="${t.id}">✎</button></div></div></article>`).join('');
  qs('#ticketsEmpty').classList.toggle('hidden',data.tickets.length>0);
  qsa('[data-ticket-qr]').forEach(b=>b.addEventListener('click',()=>openQr(b.dataset.ticketQr)));
  qsa('[data-ticket-edit]').forEach(b=>b.addEventListener('click',()=>openTicketEditor(b.dataset.ticketEdit)));
}
function renderGoHome(){
  const done=data.gohome.filter(x=>x.done).length,total=data.gohome.length;
  qs('#goHomeProgress').textContent=`${done} / ${total} checked`;
  qs('#homeChecklist').innerHTML=data.gohome.map(x=>`<div class="check-item ${x.done?'checked':''}"><input type="checkbox" data-homecheck="${x.id}" ${x.done?'checked':''}><label>${esc(x.name)}</label><button class="row-delete" data-home-delete="${x.id}" aria-label="Delete">×</button></div>`).join('');
  qsa('[data-homecheck]').forEach(c=>c.addEventListener('change',()=>{const item=data.gohome.find(x=>x.id===c.dataset.homecheck);if(item)item.done=c.checked;save()}));
  qsa('[data-home-delete]').forEach(b=>b.addEventListener('click',()=>{data.gohome=data.gohome.filter(x=>x.id!==b.dataset.homeDelete);save();toast('Check removed')}));
  qs('#readyHome').classList.toggle('hidden',!total||done!==total);
}
function renderBackup(){
  if(!qs('#backupStatus'))return;
  qs('#backupStatus').textContent=data.lastBackup?`Last backup ${new Date(data.lastBackup).toLocaleString()}`:'Download everything, including ticket images';
  qs('#restoreRecoveryBtn')?.classList.toggle('hidden',!hasRecoverySnapshot());
}
function renderMode(){qs('#modeBtn').textContent=data.mode;document.body.classList.toggle('travel-mode',data.mode==='Travel Mode')}
function render(){renderTrip();renderToday();renderPacking();renderMoney();renderPlaces();renderStay();renderTickets();renderGoHome();renderBackup();renderMode()}

function simpleForm(title,fields,onSave){
  qs('#simpleTitle').textContent=title;
  qs('#simpleFields').innerHTML=fields.map(f=>`<label class="field"><span>${esc(f.label)}</span>${f.type==='select'?`<select name="${f.name}">${f.options.map(o=>`<option ${o===f.value?'selected':''}>${esc(o)}</option>`).join('')}</select>`:`<input name="${f.name}" type="${f.type||'text'}" value="${esc(f.value||'')}" ${f.required?'required':''} placeholder="${esc(f.placeholder||'')}">`}</label>`).join('');
  qs('#simpleForm').onsubmit=e=>{e.preventDefault();const form=Object.fromEntries(new FormData(e.currentTarget).entries());onSave(form);qs('#simpleDialog').close()};
  qs('#simpleDialog').showModal();
}

qs('#modeBtn').addEventListener('click',()=>{data.mode=data.mode==='Before Trip'?'Travel Mode':'Before Trip';save();toast(`${data.mode} enabled`)});
qs('#editTripBtn').addEventListener('click',()=>simpleForm('Edit trip',[
  {label:'City',name:'city',value:data.trip.city,required:true},{label:'Country',name:'country',value:data.trip.country},{label:'Start date',name:'start',type:'date',value:data.trip.start,required:true},{label:'End date',name:'end',type:'date',value:data.trip.end,required:true}
],f=>{if(f.end<f.start){toast('End date must be after start date');return}data.trip={...data.trip,...f};selectedTodayDate='';save();toast('Trip updated')}));

qs('#editStayBtn').addEventListener('click',()=>simpleForm('Edit stay',[
  {label:'Hotel name',name:'name',value:data.stay.name,required:true},{label:'Address',name:'address',value:data.stay.address},{label:'Check-in time',name:'checkin',type:'time',value:data.stay.checkin},{label:'Check-out time',name:'checkout',type:'time',value:data.stay.checkout},{label:'Booking reference',name:'booking',value:data.stay.booking}
],f=>{data.stay={...data.stay,...f};save();toast('Stay updated')}));

function openMaps(query){if(!query)return toast('Add an address first');window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`,'_blank','noopener')}
qs('#mapsBtn').addEventListener('click',()=>openMaps(data.stay.address||data.stay.name));
qs('#bookingBtn').addEventListener('click',async()=>{if(!data.stay.booking)return toast('No booking reference');try{await navigator.clipboard.writeText(data.stay.booking);toast('Booking reference copied')}catch{toast(data.stay.booking)}});

qsa('#placeFilters .chip').forEach(c=>c.addEventListener('click',()=>{activePlaceFilter=c.dataset.filter;qsa('#placeFilters .chip').forEach(x=>x.classList.toggle('active',x===c));renderPlaces()}));
qs('#addPlaceBtn').addEventListener('click',()=>addPlace());
qs('#addPackBtn').addEventListener('click',()=>simpleForm('Add packing item',[{label:'Item',name:'name',required:true,placeholder:'Umbrella'}],f=>{data.packing.push({id:uid('p'),name:f.name,done:false});save();toast('Added to packing')}));
qs('#editBudgetBtn').addEventListener('click',()=>simpleForm('Trip budget',[{label:'Budget (RM)',name:'budget',type:'number',value:data.budget,required:true}],f=>{data.budget=Math.max(0,Number(f.budget||0));save();toast('Budget updated')}));
qs('#addExpenseBtn').addEventListener('click',()=>addExpense());
qs('#addPlanBtn').addEventListener('click',()=>addPlan());
qs('#addTicketBtn').addEventListener('click',()=>openTicketEditor());
qs('#prevDayBtn').addEventListener('click',()=>shiftSelectedDay(-1));
qs('#nextDayBtn').addEventListener('click',()=>shiftSelectedDay(1));
qs('#addGoHomeBtn').addEventListener('click',()=>simpleForm('Add final check',[{label:'Check',name:'name',required:true,placeholder:'Hotel safe checked'}],f=>{data.gohome.push({id:uid('g'),name:f.name,done:false});save();toast('Final check added')}));
qs('#resetGoHomeBtn').addEventListener('click',()=>{data.gohome.forEach(x=>x.done=false);save();toast('Go Home checks reset')});

function addPlace(){simpleForm('Add place',[{label:'Place',name:'name',required:true,placeholder:'Siam Paragon'},{label:'Category',name:'category',type:'select',value:'All',options:['All','Must go','Food','Shopping']},{label:'Note',name:'note',placeholder:'Optional'}],f=>{data.places.unshift({id:uid('l'),icon:'📍',name:f.name,category:f.category,note:f.note});save();toast('Place saved')})}
function addExpense(){simpleForm('Quick expense',[{label:'Amount (RM)',name:'amount',type:'number',required:true,placeholder:'42'},{label:'Category / note',name:'name',required:true,placeholder:'Food'}],f=>{const amount=Number(f.amount);if(!(amount>0))return toast('Enter an amount');data.expenses.push({id:uid('e'),name:f.name,amount});save();toast('Expense saved')})}
function addPlan(){simpleForm('Add plan',[{label:'Date',name:'date',type:'date',value:selectedTodayDate||data.trip.start,required:true},{label:'Time',name:'time',type:'time',value:''},{label:'Plan',name:'title',required:true,placeholder:'📍 Siam'},{label:'Note',name:'meta',placeholder:'Optional'}],f=>{data.plans.push({id:uid('d'),...f});save();toast('Plan saved')})}

qs('#quickAdd').addEventListener('click',()=>qs('#quickDialog').showModal());
qsa('[data-quick]').forEach(b=>b.addEventListener('click',()=>{qs('#quickDialog').close();({place:addPlace,expense:addExpense,ticket:()=>openTicketEditor(),plan:addPlan})[b.dataset.quick]()}));

function openTicketEditor(id=''){
  const t=data.tickets.find(x=>x.id===id)||{id:'',type:'FLIGHT',title:'',date:selectedTodayDate||data.trip.start,time:'',place:'',seat:'',code:'',qr:''};
  qs('#ticketDialogTitle').textContent=id?'Edit ticket':'Add ticket';qs('#ticketEditId').value=t.id;qs('#ticketType').value=['FLIGHT','EVENT','TRAIN','BUS','RETURN','OTHER'].includes(t.type)?t.type:'OTHER';
  qs('#ticketTitle').value=t.title;qs('#ticketDate').value=t.date;qs('#ticketTime').value=t.time;qs('#ticketPlace').value=t.place;qs('#ticketSeat').value=t.seat;qs('#ticketCode').value=t.code;
  qs('#ticketQr').value='';pendingTicketQr=t.qr||'';qs('#ticketQrHint').textContent=t.qr?'Current image saved · choose another to replace':'Optional · image is stored only in this browser';
  qs('#deleteTicketBtn').classList.toggle('hidden',!id);qs('#ticketDialog').showModal();
}
qs('#ticketQr').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{pendingTicketQr=await resizeImage(file,900,0.88);qs('#ticketQrHint').textContent='New image ready to save'}catch{toast('Could not read image')}});
function resizeImage(file,max=900,quality=.88){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{let w=img.width,h=img.height;if(Math.max(w,h)>max){const k=max/Math.max(w,h);w=Math.round(w*k);h=Math.round(h*k)}const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',quality))};img.src=r.result};r.readAsDataURL(file)})}
qs('#ticketForm').addEventListener('submit',e=>{e.preventDefault();const id=qs('#ticketEditId').value;const ticket={id:id||uid('t'),type:qs('#ticketType').value,title:qs('#ticketTitle').value.trim(),date:qs('#ticketDate').value,time:qs('#ticketTime').value,place:qs('#ticketPlace').value.trim(),seat:qs('#ticketSeat').value.trim(),code:qs('#ticketCode').value.trim(),qr:pendingTicketQr};if(!ticket.title||!ticket.date)return;const idx=data.tickets.findIndex(x=>x.id===id);if(idx>=0)data.tickets[idx]=ticket;else data.tickets.push(ticket);qs('#ticketDialog').close();save();toast('Ticket saved')});
qs('#deleteTicketBtn').addEventListener('click',()=>{const id=qs('#ticketEditId').value;if(!id)return;data.tickets=data.tickets.filter(x=>x.id!==id);qs('#ticketDialog').close();save();toast('Ticket removed')});
function openQr(id){const t=data.tickets.find(x=>x.id===id);if(!t)return;qs('#qrTitle').textContent=t.title;qs('#qrCodeText').textContent=t.code||'No booking reference';qs('#qrMeta').textContent=[t.date,t.time,t.seat?`Seat ${t.seat}`:''].filter(Boolean).join(' · ');qs('#qrImage').classList.toggle('hidden',!t.qr);qs('#fakeQr').classList.toggle('hidden',!!t.qr);if(t.qr)qs('#qrImage').src=t.qr;qs('#qrDialog').showModal()}

function backupFilename(){
  const city=(data.trip.city||'Trip').replace(/[^a-z0-9À-ɏ一-鿿_-]+/gi,'-').replace(/^-+|-+$/g,'')||'Trip';
  return `Travel-Lah-${city}-${data.trip.start||localISO()}-backup.json`;
}
function exportBackup(){
  const exportedAt=new Date().toISOString();
  const payload={app:'Travel Lah!',backupVersion:2,exportedAt,data:{...data,lastBackup:exportedAt,version:4}};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=backupFilename();document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  data.lastBackup=exportedAt;localStorage.setItem(LS,JSON.stringify(data));render();toast('Trip backup downloaded');
}
function saveRecoverySnapshot(){
  try{localStorage.setItem(RECOVERY_LS,JSON.stringify({savedAt:new Date().toISOString(),data}))}catch{}
}
function hasRecoverySnapshot(){
  try{return !!JSON.parse(localStorage.getItem(RECOVERY_LS))?.data}catch{return false}
}
async function importBackup(file){
  try{
    const raw=JSON.parse(await file.text()),incoming=raw && raw.data ? raw.data : raw;
    if(!incoming || !incoming.trip || !incoming.trip.start || !incoming.trip.end || !Array.isArray(incoming.tickets)) throw new Error('Invalid backup');
    if(!confirm(`Restore backup for ${incoming.trip.city||'this trip'}?\n\nYour current Travel Lah! data will be kept as an automatic recovery snapshot.`)) return;
    saveRecoverySnapshot();
    data=normalizeData(incoming);selectedTodayDate='';activePlaceFilter='All';save();toast('Trip backup restored');showView('home');
  }catch{toast('Could not import this backup')}
}
function restoreRecovery(){
  try{
    const snap=JSON.parse(localStorage.getItem(RECOVERY_LS));
    if(!snap?.data) return toast('No recovery snapshot');
    if(!confirm('Undo the last import and restore your previous Travel Lah! data?')) return;
    data=normalizeData(snap.data);selectedTodayDate='';activePlaceFilter='All';localStorage.removeItem(RECOVERY_LS);save();toast('Previous trip restored');showView('home');
  }catch{toast('Could not restore recovery snapshot')}
}
qs('#exportBackupBtn').addEventListener('click',exportBackup);
qs('#importBackupBtn').addEventListener('click',()=>{qs('#backupFileInput').value='';qs('#backupFileInput').click()});
qs('#backupFileInput').addEventListener('change',e=>{const file=e.target.files?.[0];if(file)importBackup(file)});
qs('#restoreRecoveryBtn').addEventListener('click',restoreRecovery);

let deferredInstallPrompt=null;
function isStandalone(){return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true}
function isIOS(){return /iphone|ipad|ipod/i.test(navigator.userAgent)}
function updateInstallUI(){
  const status=qs('#installStatus'),btn=qs('#installAppBtn');
  if(!status||!btn)return;
  if(isStandalone()){status.textContent='Installed · opens like an app';btn.disabled=true;btn.classList.add('is-disabled');return}
  btn.disabled=false;btn.classList.remove('is-disabled');
  status.textContent=isIOS()?'Safari: Share → Add to Home Screen':(deferredInstallPrompt?'Ready to install':'Add it to your Home Screen');
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;updateInstallUI()});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;updateInstallUI();toast('Travel Lah! installed')});
qs('#installAppBtn').addEventListener('click',async()=>{
  if(isStandalone()) return toast('Travel Lah! is already installed');
  if(deferredInstallPrompt){deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;updateInstallUI();return}
  if(isIOS()) return alert('On iPhone / iPad:\n\n1. Open Travel Lah! in Safari\n2. Tap the Share button\n3. Choose “Add to Home Screen”\n4. Tap Add');
  alert('Open your browser menu and choose “Install app” or “Add to Home screen”.');
});
updateInstallUI();

async function initPWA(){
  const status=qs('#appRuntimeStatus');
  if(location.protocol==='file:'){if(status)status.textContent='Preview mode · deploy over HTTPS to enable install/offline';return}
  if(!('serviceWorker' in navigator)){if(status)status.textContent='Offline install is not supported in this browser';return}
  try{
    const reg=await navigator.serviceWorker.register('./service-worker.js');
    if(status)status.textContent=navigator.serviceWorker.controller?'Offline ready':'Offline cache preparing…';
    reg.update().catch(()=>{});
    navigator.serviceWorker.addEventListener('controllerchange',()=>{if(status)status.textContent='Offline ready'});
  }catch{if(status)status.textContent='App works, but offline cache could not start'}
}
initPWA();

qs('#resetDemo').addEventListener('click',()=>{if(!confirm('Reset Travel Lah! to the sample trip? Your current local data will be replaced.'))return;saveRecoverySnapshot();localStorage.removeItem(LS);data=clone(seed);activePlaceFilter='All';selectedTodayDate='';save();toast('Demo reset · recovery snapshot saved')});
window.addEventListener('pageshow',()=>{render();updateInstallUI()});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')renderTrip()});
render();
